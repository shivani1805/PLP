import { AdminDataService } from './../admin-data.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserClass } from '../userClass';



@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router: Router,private adminSer: AdminDataService) { }


  loginAdmin = new FormGroup({
   email: new FormControl('', [Validators.email]),
    password: new FormControl('', Validators.required),
    username:new FormControl('',Validators.required),
    role:new FormControl('',Validators.required)
  });


  ngOnInit(): void {
  }
  login() {

    let username = this.loginAdmin.get('username').value;
    let password = this.loginAdmin.get('password').value;
    let email=null;
    let role="Admin";
    let tempUser:UserClass=new UserClass(username,password,role,email);
     this.adminSer.login(tempUser).subscribe(data => {
      if(!data)
      {
        window.alert("Invalid Login Credentials");
        console.log(data);
      }
      else{
        console.log(data);
        this.router.navigate(["add-bus-or-route"]);
      }
    }); 
 
  }
}
