import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Bus } from './Bus';


@Injectable({
  providedIn: 'root'
})
export class BusService 
{
  localurl='./assets/busbooking.json';
  public tempBus:Bus;
  public flag:boolean=false;
  public busDb:any[]=[];
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
}
  getBus()
  {
   this.http.get<Bus[]>('http://localhost:8080/api/bus').subscribe(resp=>
   {
    for(const b of(resp as any))
    {
      this.busDb.push
      ({
        id:b.id,
    sourceStation:b.sourceStation,
    destinationStation:b.destinationStation,
    boardingTime:b.boardingTime,
    dropTime:b.dropTime,
    busType:b.busType,
    totalSeats:b.totalSeats,
    fare:b.fare,
    SeatNo:b.SeatNo,
    seatsBooked:b.seatsBooked
      })
    }
   console.log(this.busDb);
  });
  }
  addBus(Bus:Bus)
  {
    return this.http.post('http://localhost:8080/bus',Bus);
  }
  updateBusBySourceStation(id:any,sourceStation:any)
  {
    return this.http.put('http://localhost:8080/api/update/sourceStation/'+id+'/'+sourceStation,this.httpOptions);
  }


  deleteBus(id:any)
  {
    return this.http.delete('http://localhost:8080/bus/'+id);
  }
 
  updateBus(id:any,Bus:Bus)
  {
    return this.http.put('http://localhost:8080/bus/'+id,Bus);
  }
    
}
