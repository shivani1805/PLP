import { AdminDataService } from './../admin-data.service';
import { BookingServiceService } from './../booking-service.service';
import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-cancel-booking',
  templateUrl: './cancel-booking.component.html',
  styleUrls: ['./cancel-booking.component.css']
})
export class CancelBookingComponent implements OnInit {
  booking = [];
  message : any;

  constructor(private adminSer:AdminDataService,private router:Router) { }
  cancelTicket = new FormGroup({
    bookingId: new FormControl('',Validators.required)
  })
 
    ngOnInit(): void 
    {
     document.getElementById("message").style.display="none";

    }
  cancelBooking()
  { let bookingId = this.cancelTicket.get('bookingId').value;
    this.message=null;
    this.adminSer.deleteBooking(bookingId).pipe(catchError((error:HttpErrorResponse) =>{
      this.router.navigate(["show-error", error.error.message]);
      return throwError(error.error.message);
    })).subscribe(data => {
      console.log(data);
      this.message="Booking with id: " + data+"is cancelled successfully";
      document.getElementById("message").style.display="block";
      
      


})
}
}