import { AdminDataService } from './../admin-data.service';
import { BusClass } from './../BusClass';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Bus } from 'src/app/Bus';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BusService } from 'src/app/bus.service';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-remove-bus',
  templateUrl: './remove-bus.component.html',
  styleUrls: ['./remove-bus.component.css']
})
export class RemoveBusComponent implements OnInit {
  flag1:boolean;
  
  bus:BusClass[];

  constructor(private adminSer:AdminDataService,private router:Router) { }
   cancelBus=new FormGroup({
   busId:new FormControl('',Validators.required)
 })
  ngOnInit(): void {
    
  }
  
  removeBus(){
    this.adminSer.getBus().subscribe(data => this.bus=data);
    let busId=this.cancelBus.get('busId').value;
  
    this.adminSer.deleteBus(busId).pipe(catchError((error:HttpErrorResponse)=>{
      this.router.navigate(["show-error",error.error.message]);
      return throwError(error.error.message)})).subscribe(data=>console.log(data));
        for(let i=0;i<this.bus.length;i++)
        {
          if(this.bus[i].busId==busId)
          {
            this.flag1=true;
            this.adminSer.deleteBus(busId).subscribe(data=>(console.log(data)));
           
          }
        }
        
  }

}
