import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { Customer } from '../Customer';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
flagEmail=false;
flagUserName=false;
flagPhoneNumber=false;
  constructor(private custSer:CustomerService,private router:Router ) {}
  signupCustomer=new FormGroup({
    customerName: new FormControl('',[Validators.required,Validators.pattern(/^[A-Z][a-z]{3,10}[\.]{0,1}[A-Za-z\s]{0,10}$/)]),
    customerPhoneNumber: new FormControl('',[Validators.required,Validators.pattern(/^[6-9][0-9]{9}$/)]),
    customerEmail: new FormControl('',[Validators.required,Validators.pattern(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/)]),
    customerUserName: new FormControl('',[Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]){6,}/)]),
    customerPassword: new FormControl('',[Validators.required,Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/)]),
    customerAge: new FormControl('',[Validators.required,Validators.pattern(/^[0-9]{1,2}$/)])
  });
  ngOnInit(): void {
    this.custSer.getCustomer();
  }
  signup()
    {
      if(this.signupCustomer.valid)
      {
      let name = this.signupCustomer.get('customerName').value;
      let phoneNo = this.signupCustomer.get('customerPhoneNumber').value;
      let email:String = this.signupCustomer.get('customerEmail').value;
      let id = this.custSer.customerDb[0].id;
      for(let i=1;i<this.custSer.customerDb.length;i++)
      {
        if(id<this.custSer.customerDb[i].id)
        id=this.custSer.customerDb[i].id;
      }
      id++;
      let userName = this.signupCustomer.get('customerUserName').value;
      let password = this.signupCustomer.get('customerPassword').value;
      let age= this.signupCustomer.get('customerAge').value;
      for(let i=0;i<this.custSer.customerDb.length;i++)
      {
        if(email==this.custSer.customerDb[i].customerEmail)
        {
          this.flagEmail=true;
          break;
        }
      }
      for(let i=0;i<this.custSer.customerDb.length;i++)
      {
        if(this.custSer.customerDb[i].customerUserName==userName)
        {
          this.flagUserName=true;
          break;
        }
      }
      for(let i=0;i<this.custSer.customerDb.length;i++)
      {
        if(this.custSer.customerDb[i].customerPhoneNumber==phoneNo)
        {
          this.flagPhoneNumber=true;
          break;
        }
      }
      if(this.flagEmail==false&&this.flagUserName==false&&this.flagPhoneNumber==false)
      {
        let tempCustomer:Customer=new Customer(name, phoneNo, email, id, userName,password,age);
        this.custSer.addCustomer(tempCustomer).subscribe(data=>{console.log(data)}); 
        this.router.navigateByUrl("/home"); 
      }
    }
    }
}
