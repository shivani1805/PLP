import { AdminDataService } from './../admin-data.service';
import { BusClass } from './../BusClass';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Bus } from 'src/app/Bus';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { BusService } from 'src/app/bus.service';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-update-boarding-time',
  templateUrl: './update-boarding-time.component.html',
  styleUrls: ['./update-boarding-time.component.css']
})
export class UpdateBoardingTimeComponent implements OnInit {
  flag1:boolean;
  tempBus:Bus;
  bus:BusClass[];
  constructor(private adminSer:AdminDataService,private router:Router) { }
  updateBoarding = new FormGroup({
    busId : new FormControl('',Validators.required),
    boardingTime : new FormControl('',Validators.required)
  })
  ngOnInit(): void {
    this.adminSer.getBus().subscribe(data => this.bus=data);
  }
  updateBoardingTime()
  {
    let busId=this.updateBoarding.get('busId').value;
    let boardingTime=this.updateBoarding.get('boardingTime').value;
    this.adminSer.updateBusByBoardingTime(busId, boardingTime).pipe(catchError((error:HttpErrorResponse)=>{
      this.router.navigate(["show-error",error.error.message]);
      return throwError(error.error.message)})).subscribe(data=>console.log(data));
    for(let i=0;i<this.bus.length;i++)
    {
     
        if(this.bus[i].busId==busId)
        {
          this.adminSer.updateBusByBoardingTime(busId, boardingTime).subscribe(data=>(console.log(data)));
          this.flag1=true;
        }
      }
       }
    } 
  
  


